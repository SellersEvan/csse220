module ImplementingDesignPart2 {
	requires junit;
}